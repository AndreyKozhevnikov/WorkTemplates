﻿using DevExpress.XtraReports.UI;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

namespace dxT1217741.Module {
    public partial class Report1 : DevExpress.XtraReports.UI.XtraReport {
        public Report1() {
            InitializeComponent();
        }
    }
}
